import { useEffect, useRef, useState } from 'react';
import { format, parseISO, differenceInMilliseconds } from 'date-fns';

const STORAGE_KEY = "fj_reminders_push_v1";

function makeBeep(){ try { const ctx=new (window.AudioContext||window.webkitAudioContext)(); const o=ctx.createOscillator(); const g=ctx.createGain(); o.type='sine'; o.frequency.value=880; g.gain.value=0.0001; o.connect(g); g.connect(ctx.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime+0.01); g.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime+0.6); o.stop(ctx.currentTime+0.7);}catch(e){} }

export default function Home(){
  const [reminders,setReminders] = useState([]);
  const [title,setTitle] = useState('');
  const [datetime,setDatetime] = useState('');
  const timers = useRef({});
  const [subscribed,setSubscribed] = useState(false);
  const [publicKey,setPublicKey] = useState('');
  const [adminKey,setAdminKey] = useState('');

  useEffect(()=>{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw) setReminders(JSON.parse(raw));
    fetch('/api/vapid').then(r=>r.json()).then(d=>{ if(d.publicKey) setPublicKey(d.publicKey) }).catch(()=>{});
  },[]);

  useEffect(()=>{
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reminders));
    Object.values(timers.current).forEach(clearTimeout);
    timers.current = {};
    reminders.forEach(r=>{
      if(r.done) return;
      const when = parseISO(r.at);
      const diff = differenceInMilliseconds(when, new Date());
      if(diff<=0){ triggerReminder(r); markDone(r.id); }
      else {
        timers.current[r.id] = setTimeout(()=>{ triggerReminder(r); markDone(r.id); }, diff);
      }
    });
    return ()=> Object.values(timers.current).forEach(clearTimeout);
  },[reminders]);

  function addReminder(e){ e.preventDefault(); if(!title.trim()||!datetime) return alert('أدخل عنوان وتاريخ صحيح'); const newR = { id:'r_'+Date.now(), title: title.trim(), at: new Date(datetime).toISOString(), done:false }; setReminders(prev=>[newR,...prev]); setTitle(''); setDatetime(''); }

  function deleteReminder(id){ if(!confirm('هل تريد حذف هذا التذكير؟')) return; setReminders(prev=>prev.filter(r=>r.id!==id)); }
  function markDone(id){ setReminders(prev=>prev.map(r=> r.id===id? {...r, done:true}: r)); }
  function triggerReminder(r){ makeBeep(); try { if('Notification' in window && Notification.permission==='granted'){ new Notification('تذكير: '+r.title, { body: 'الوقت: '+format(parseISO(r.at),'yyyy-MM-dd HH:mm') }); } else { alert('تذكير: '+r.title); } } catch(e){ alert('تذكير: '+r.title); } }

  async function subscribePush(){ if(!('serviceWorker' in navigator)) return alert('Service Workers غير مدعوم'); if(Notification.permission==='default') await Notification.requestPermission(); if(Notification.permission!=='granted') return alert('الرجاء السماح بالإشعارات'); const reg = await navigator.serviceWorker.register('/sw.js'); const sub = await reg.pushManager.subscribe({ userVisibleOnly:true, applicationServerKey: urlBase64ToUint8Array(publicKey) }); const res = await fetch('/api/subscribe', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(sub) }); if(res.ok) { alert('تم الاشتراك في الإشعارات'); setSubscribed(true); } else alert('فشل الاشتراك'); }

  async function unsubscribePush(){ const reg = await navigator.serviceWorker.getRegistration(); if(!reg) return; const sub = await reg.pushManager.getSubscription(); if(!sub) return alert('لا توجد اشتراكات'); await fetch('/api/unsubscribe', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(sub) }); await sub.unsubscribe(); alert('تم إلغاء الاشتراك'); setSubscribed(false); }

  async function triggerServerPush(){ if(!adminKey) return alert('أدخل مفتاح المشرف'); const payload = { title: 'تذكير من فيس أردني', body: 'تذكير عام' }; const res = await fetch('/api/trigger', { method:'POST', headers:{ 'Content-Type':'application/json', 'x-admin-key': adminKey }, body: JSON.stringify(payload) }); const data = await res.json(); alert('تم إرسال الإشعارات — النتائج: '+JSON.stringify(data.results || data)); }

  useEffect(()=>{ (async ()=>{ try{ const reg = await navigator.serviceWorker.getRegistration(); if(!reg) return setSubscribed(false); const sub = await reg.pushManager.getSubscription(); setSubscribed(!!sub); }catch(e){} })(); },[]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-sky-100 text-sky-900">
      <header className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-white rounded-lg shadow flex items-center justify-center text-2xl">🔔</div>
          <div>
            <h1 className="text-2xl font-bold">تذكير المواعيد — فيس أردني</h1>
            <p className="text-sm text-sky-600">نسخة متقدمة بدعم Web Push وواجهة إدارة</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6 space-y-6">
        <section className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-lg font-semibold mb-4">اشتراك إشعارات الويب</h2>
          <div className="flex gap-3">
            <button onClick={subscribePush} className="px-4 py-2 bg-sky-500 text-white rounded">اشترك بالإشعارات</button>
            <button onClick={unsubscribePush} className="px-4 py-2 border rounded text-sky-700">إلغاء الاشتراك</button>
            <div className="ml-auto flex items-center gap-2">
              <input placeholder="مفتاح المشرف" value={adminKey} onChange={e=>setAdminKey(e.target.value)} className="border rounded px-3 py-2" />
              <button onClick={triggerServerPush} className="px-3 py-2 bg-sky-600 text-white rounded">أرسل إشعار تجريبي</button>
            </div>
          </div>
        </section>

        <section className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-lg font-semibold mb-4">إنشاء تذكير جديد</h2>
          <form className="grid grid-cols-1 gap-3 sm:grid-cols-3" onSubmit={addReminder}>
            <input className="col-span-2 border rounded px-3 py-2" placeholder="العنوان" value={title} onChange={e=>setTitle(e.target.value)} />
            <input type="datetime-local" className="border rounded px-3 py-2" value={datetime} onChange={e=>setDatetime(e.target.value)} />
            <div className="sm:col-span-3 flex gap-3">
              <button className="px-4 py-2 bg-sky-500 text-white rounded">إضافة</button>
              <button type="button" onClick={()=>{ setReminders([]); localStorage.removeItem(STORAGE_KEY); }} className="px-4 py-2 border rounded">مسح الكل</button>
            </div>
          </form>
        </section>

        <section className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-lg font-semibold mb-4">قائمة التذكيرات ({reminders.length})</h2>
          <ul className="space-y-3">
            {reminders.map(r=>(
              <li key={r.id} className={`p-4 rounded-lg border ${r.done ? 'opacity-60 line-through' : ''} flex justify-between items-center`}>
                <div>
                  <div className="font-semibold">{r.title}</div>
                  <div className="text-sm text-sky-600">{format(parseISO(r.at),'yyyy-MM-dd HH:mm')}</div>
                </div>
                <div className="flex gap-2">
                  {!r.done && <button onClick={()=>{ triggerReminder(r); markDone(r.id); }} className="px-3 py-1 bg-sky-500 text-white rounded">تشغيل الآن</button>}
                  <button onClick={()=>deleteReminder(r.id)} className="px-3 py-1 border rounded text-sky-700">حذف</button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>

      <footer className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-sky-600 text-white px-4 py-2 rounded shadow">صُنع في الأردن © 2025 — فيس أردني</footer>
    </div>
  );
}

// helper
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = typeof window !== 'undefined' ? window.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
