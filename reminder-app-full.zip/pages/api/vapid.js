export default function handler(req,res){ const PUBLIC=process.env.VAPID_PUBLIC_KEY||''; res.status(200).json({ publicKey: PUBLIC }); }
