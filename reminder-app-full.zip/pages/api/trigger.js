import webpush from 'web-push';
import { promises as fs } from 'fs';
import path from 'path';
const FILE = path.join(process.cwd(), 'subscriptions.json');
async function load(){ try { const txt = await fs.readFile(FILE,'utf8'); return JSON.parse(txt||'[]'); } catch(e){ return []; } }
export default async function handler(req, res){ if(req.method!=='POST') return res.status(405).end(); const adminKey = req.headers['x-admin-key']; if(!adminKey || adminKey !== process.env.ADMIN_KEY) return res.status(401).json({ error:'unauthorized' }); const payload = req.body || { title:'تذكير', body:'رسالة جديدة' }; webpush.setVapidDetails('mailto:admin@facejordan.local', process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY); const list = await load(); const results = []; await Promise.all(list.map(async s=>{ try{ await webpush.sendNotification(s, JSON.stringify(payload)); results.push({ endpoint: s.endpoint, ok:true }); }catch(e){ results.push({ endpoint: s.endpoint, ok:false, error: e && e.body ? e.body : String(e) }); } })); res.json({ results }); }
