import { promises as fs } from 'fs';
import path from 'path';
const FILE = path.join(process.cwd(), 'subscriptions.json');
async function load(){ try { if(!await fs.stat(FILE).catch(()=>false)) await fs.writeFile(FILE,'[]'); const txt = await fs.readFile(FILE,'utf8'); return JSON.parse(txt||'[]'); } catch(e){ return []; } }
async function save(arr){ await fs.writeFile(FILE, JSON.stringify(arr, null, 2)); }
export default async function handler(req, res){ if(req.method!=='POST') return res.status(405).end(); const sub = req.body; let list = await load(); list = list.filter(s=>s.endpoint !== sub.endpoint); await save(list); res.json({ ok:true }); }
