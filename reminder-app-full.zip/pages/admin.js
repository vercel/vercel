import { useState } from 'react';
export default function Admin(){
  const [key,setKey]=useState('');
  const [msg,setMsg]=useState(''); 
  async function send(){
    const res=await fetch('/api/trigger',{ method:'POST', headers:{ 'Content-Type':'application/json', 'x-admin-key': key }, body: JSON.stringify({ title:'إشعار من لوحة الإدارة', body: msg }) });
    const d=await res.json(); alert('نتيجة الإرسال: '+JSON.stringify(d.results||d));
  }
  return (<div className="min-h-screen bg-sky-50 p-6"><div className="max-w-xl mx-auto bg-white p-6 rounded shadow"><h2 className="font-bold mb-3">لوحة إدارة الإشعارات</h2><input className="w-full border rounded p-2 mb-2" placeholder="مفتاح المشرف" value={key} onChange={e=>setKey(e.target.value)} /><textarea className="w-full border rounded p-2 mb-2" placeholder="نص الإشعار" value={msg} onChange={e=>setMsg(e.target.value)} rows={4} /><button onClick={send} className="px-4 py-2 bg-sky-600 text-white rounded">أرسل</button></div></div>)
}
