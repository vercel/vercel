const fs = require('fs');
const path = require('path');
const FILE = path.join(process.cwd(), 'subscriptions.json');
function load(){ try{ if(!fs.existsSync(FILE)) fs.writeFileSync(FILE, '[]'); return JSON.parse(fs.readFileSync(FILE,'utf8')||'[]') }catch(e){ return [] } }
function save(arr){ fs.writeFileSync(FILE, JSON.stringify(arr, null, 2)) }
module.exports = { load, save, FILE };
