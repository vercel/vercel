self.addEventListener('push', function(event) {
  let data = {};
  try { data = event.data.json(); } catch(e){ data = { title: 'تذكير', body: 'لديك تذكير جديد' }; }
  const title = data.title || 'تذكير';
  const options = {
    body: data.body || '',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    data: data.url || '/'
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function(event){
  event.notification.close();
  event.waitUntil(clients.matchAll({type:'window'}).then(function(clientList){
    if (clients.openWindow) return clients.openWindow(event.notification.data || '/');
  }));
});
