'use strict';

exports.handler = async function () {
  return {
    statusCode: 200,
    headers: {},
    body: 'cow:NO_REPLACE_TO_AVOID_CRC_MISMATCH'
  };
};
