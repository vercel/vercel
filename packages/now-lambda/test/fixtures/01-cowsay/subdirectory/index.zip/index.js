'use strict';

exports.handler = async function () {
  return {
    statusCode: 200,
    headers: {},
    body: 'yoda:NO_REPLACE_TO_AVOID_CRC_MISMATCH'
  };
};
