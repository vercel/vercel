include(":app")
rootProject.name="JOReelsAndroid"
