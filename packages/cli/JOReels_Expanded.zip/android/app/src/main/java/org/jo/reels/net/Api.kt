package org.jo.reels.net
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
data class AuthResponse(val token: String, val user: User)
data class User(val id: String, val username: String, val avatarUrl: String?)
data class Video(val id: String, val url: String, val caption: String, val authorId: String, val authorName: String, val createdAt: String, val likes: Int)
interface ApiService {
    @POST("/api/auth/register") suspend fun register(@Body body: Map<String,String>): retrofit2.Response<Map<String, String>>
    @POST("/api/auth/login") suspend fun login(@Body body: Map<String,String>): retrofit2.Response<AuthResponse>
    @GET("/api/videos") suspend fun feed(): List<Video>
    @Multipart @POST("/api/videos") suspend fun upload(@Header("Authorization") bearer: String, @Part video: MultipartBody.Part, @Part("caption") caption: String): Video
    @POST("/api/videos/{id}/like") suspend fun like(@Header("Authorization") bearer: String, @Path("id") id: String): Map<String, Int>
}
object Api {
    private val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
    private val client = OkHttpClient.Builder().addInterceptor(logging).build()
    val service: ApiService = Retrofit.Builder().baseUrl("http://10.0.2.2:4000").client(client).addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)
}
