package org.jo.reels.ui
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.jo.reels.R
import java.io.InputStream
class UploadActivity: AppCompatActivity() {
    private val PICK = 1001; private var fileUri: Uri? = null; private lateinit var token: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_upload); token = intent.getStringExtra("token") ?: ""
        val etCaption = findViewById<EditText>(R.id.etCaption); val btnPick = findViewById<Button>(R.id.btnPick); val btnUpload = findViewById<Button>(R.id.btnUpload)
        btnPick.setOnClickListener { val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }; startActivityForResult(Intent.createChooser(i, "اختر فيديو"), PICK) }
        btnUpload.setOnClickListener { if (fileUri == null) { Toast.makeText(this, "اختر فيديو أولاً", Toast.LENGTH_SHORT).show(); return@setOnClickListener }; val caption = etCaption.text.toString(); uploadVideo(fileUri!!, caption) }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (requestCode == PICK && resultCode == Activity.RESULT_OK) fileUri = data?.data }
    private fun uploadVideo(uri: Uri, caption: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val client = OkHttpClient(); val fileName = getFileName(uri) ?: "video.mp4"; val input: InputStream? = contentResolver.openInputStream(uri); val bytes = input!!.readBytes()
                val reqFile = RequestBody.create("video/mp4".toMediaTypeOrNull(), bytes)
                val body = MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("caption", caption).addFormDataPart("video", fileName, reqFile).build()
                val req = Request.Builder().url("http://10.0.2.2:4000/api/videos").addHeader("Authorization", "Bearer " + token).post(body).build()
                val res = client.newCall(req).execute()
                withContext(Dispatchers.Main) { if (res.isSuccessful) { Toast.makeText(this@UploadActivity, "تم الرفع", Toast.LENGTH_SHORT).show(); finish() } else Toast.makeText(this@UploadActivity, "فشل الرفع", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) { withContext(Dispatchers.Main) { Toast.makeText(this@UploadActivity, "خطأ: " + e.message, Toast.LENGTH_LONG).show() } }
        }
    }
    private fun getFileName(uri: Uri): String? {
        var name: String? = null; val c = contentResolver.query(uri, null, null, null, null); c?.use { if (it.moveToFirst()) { val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (idx >= 0) name = it.getString(idx) } }; return name
    }
}
