package org.jo.reels.ui
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView
import kotlinx.coroutines.*
import org.jo.reels.R
import org.jo.reels.net.Api
import org.jo.reels.net.Video
class FeedActivity: AppCompatActivity() {
    private lateinit var rv: RecyclerView; private lateinit var btnUpload: Button; private val scope = CoroutineScope(Dispatchers.IO)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_feed)
        rv = findViewById(R.id.rvFeed); btnUpload = findViewById(R.id.btnUpload)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        btnUpload.setOnClickListener { val i = Intent(this, UploadActivity::class.java); i.putExtra("token", intent.getStringExtra("token")); startActivity(i) }
        scope.launch { val videos = try { Api.service.feed() } catch(e: Exception) { listOf<Video>() }; withContext(Dispatchers.Main) { rv.adapter = VideoAdapter(videos) } }
    }
    class VideoVH(val pv: PlayerView): RecyclerView.ViewHolder(pv)
    inner class VideoAdapter(private val items: List<Video>): RecyclerView.Adapter<VideoVH>(){
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoVH { val pv = layoutInflater.inflate(R.layout.item_video, parent, false) as PlayerView; return VideoVH(pv) }
        override fun onBindViewHolder(holder: VideoVH, position: Int) { val player = ExoPlayer.Builder(this@FeedActivity).build(); holder.pv.player = player; player.setMediaItem(MediaItem.fromUri(items[position].url)); player.prepare(); player.playWhenReady = true }
        override fun getItemCount(): Int = items.size
    }
}
