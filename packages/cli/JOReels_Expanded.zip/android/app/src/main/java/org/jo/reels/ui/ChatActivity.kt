package org.jo.reels.ui
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import org.jo.reels.R
class ChatActivity: AppCompatActivity() {
    private lateinit var socket: Socket; private val messages = ArrayList<String>(); private lateinit var adapter: ArrayAdapter<String>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_chat)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages); val lv = findViewById<ListView>(R.id.lvChat); lv.adapter = adapter
        val et = findViewById<EditText>(R.id.etMessage); val btn = findViewById<Button>(R.id.btnSend)
        socket = IO.socket("http://10.0.2.2:4000"); socket.connect()
        socket.on("message") { args -> runOnUiThread { messages.add(args[0].toString()); adapter.notifyDataSetChanged() } }
        btn.setOnClickListener { val text = et.text.toString().trim(); if(text.isNotEmpty()) socket.emit("message", { text }) }
    }
    override fun onDestroy() { socket.disconnect(); super.onDestroy() }
}
