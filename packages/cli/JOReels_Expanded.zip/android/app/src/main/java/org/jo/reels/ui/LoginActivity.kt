package org.jo.reels.ui
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jo.reels.R
import org.jo.reels.net.Api
class LoginActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val etUser = findViewById<EditText>(R.id.etUser); val etPass = findViewById<EditText>(R.id.etPass)
        val btnRegister = findViewById<Button>(R.id.btnRegister); val btnLogin = findViewById<Button>(R.id.btnLogin)
        btnRegister.setOnClickListener {
            val u = etUser.text.toString().trim(); val p = etPass.text.toString().trim()
            if(u.isEmpty()||p.isEmpty()){ Toast.makeText(this,"املأ الحقول",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            CoroutineScope(Dispatchers.IO).launch {
                val res = Api.service.register(mapOf("username" to u, "password" to p))
                withContext(Dispatchers.Main) { if (res.isSuccessful) Toast.makeText(this@LoginActivity, "تم التسجيل", Toast.LENGTH_SHORT).show() else Toast.makeText(this@LoginActivity, "فشل التسجيل", Toast.LENGTH_SHORT).show() }
            }
        }
        btnLogin.setOnClickListener {
            val u = etUser.text.toString().trim(); val p = etPass.text.toString().trim()
            if(u.isEmpty()||p.isEmpty()){ Toast.makeText(this,"املأ الحقول",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            CoroutineScope(Dispatchers.IO).launch {
                val res = Api.service.login(mapOf("username" to u, "password" to p))
                withContext(Dispatchers.Main) {
                    if (res.isSuccessful) {
                        val token = res.body()!!.token
                        val i = Intent(this@LoginActivity, FeedActivity::class.java)
                        i.putExtra("token", token); startActivity(i); finish()
                    } else Toast.makeText(this@LoginActivity, "بيانات غير صحيحة", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
