# JO Reels — Expanded Bundle
This bundle contains a demo Node.js backend and an Android app skeleton pre-wired to it.
Run backend: cd backend && cp .env.example .env && npm install && npm start
Open Android Studio and import the 'android' folder. Use emulator and base URL http://10.0.2.2:4000
