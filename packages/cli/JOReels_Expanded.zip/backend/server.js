const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const { Server } = require('socket.io');
require('dotenv').config();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
const db = { users: [], videos: [], comments: [], ads: [] };
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, UPLOAD_DIR)));
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '_' + Math.round(Math.random()*1e9) + ext);
  }
});
const upload = multer({ storage });
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  if(!h.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
  const token = h.slice(7);
  try { const payload = jwt.verify(token, JWT_SECRET); req.user = payload; next(); }
  catch(e){ return res.status(401).json({ error: 'Invalid token' }); }
}
// Auth
app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username & password required' });
  if (db.users.find(u => u.username === username)) return res.status(400).json({ error: 'exists' });
  const user = { id: uuidv4(), username, passwordHash: bcrypt.hashSync(password,10), avatarUrl: null, createdAt: new Date().toISOString() };
  db.users.push(user);
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, avatarUrl: user.avatarUrl } });
});
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const u = db.users.find(x => x.username === username);
  if (!u || !bcrypt.compareSync(password, u.passwordHash)) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ id: u.id, username: u.username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: u.id, username: u.username, avatarUrl: u.avatarUrl } });
});
// Videos
app.post('/api/videos', auth, upload.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'video required' });
  const { caption } = req.body || {};
  const video = {
    id: uuidv4(),
    url: `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`,
    caption: caption || '',
    authorId: req.user.id,
    authorName: req.user.username,
    createdAt: new Date().toISOString(),
    likes: 0,
    views: 0
  };
  db.videos.unshift(video);
  res.json(video);
});
app.get('/api/videos', (req, res) => res.json(db.videos));
app.get('/api/videos/:id', (req, res) => {
  const v = db.videos.find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'not_found' });
  v.views = (v.views || 0) + 1;
  res.json(v);
});
app.post('/api/videos/:id/like', auth, (req, res) => {
  const v = db.videos.find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'not_found' });
  v.likes = (v.likes || 0) + 1;
  res.json({ likes: v.likes });
});
app.post('/api/videos/:id/comment', auth, (req, res) => {
  const v = db.videos.find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'not_found' });
  const { text } = req.body || {};
  const c = { id: uuidv4(), videoId: v.id, userId: req.user.id, username: req.user.username, text, createdAt: new Date().toISOString() };
  db.comments.push(c);
  res.json(c);
});
app.get('/api/videos/:id/comments', (req, res) => res.json(db.comments.filter(c => c.videoId === req.params.id)));
app.post('/api/ads', auth, upload.single('image'), (req, res) => {
  const { title, link } = req.body || {};
  const img = req.file ? `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}` : null;
  const ad = { id: uuidv4(), title, link, imageUrl: img, ownerId: req.user.id, createdAt: new Date().toISOString() };
  db.ads.push(ad);
  res.json(ad);
});
app.get('/api/ads', (req, res) => res.json(db.ads));
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('join', (username) => { socket.data.username = username; });
  socket.on('message', (payload) => { io.emit('message', { from: socket.data.username || 'anon', text: payload.text, at: new Date().toISOString() }); });
});
app.get('/api/health', (req, res) => res.json({ ok: true }));
server.listen(PORT, () => console.log('JO Reels backend listening on http://localhost:' + PORT));