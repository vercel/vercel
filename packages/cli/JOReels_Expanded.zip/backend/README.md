Backend quick start: cp .env.example .env && npm install && npm start
